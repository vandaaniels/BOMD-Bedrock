# Bosses of Mass Destruction: Bedrock Edition

Current source: **2.1.17** for Minecraft Bedrock **1.26.40**.

This repository contains the Behavior Pack (`BP/`) and Resource Pack (`RP/`) sources for the Bedrock port of Bosses of Mass Destruction.

## Current encounters

- Night Lich
- Nether Gauntlet
- Void Blossom
- Obsidilith

## Compatibility

- Minecraft Bedrock 1.26.40
- `@minecraft/server` 2.9.0 stable

## 2.1.17

- Fixed Obsidilith arena materialization when locating it through `scriptevent`.
- Fixed End Frame interaction by reading the player's selected inventory slot instead of the nonexistent interaction-event `itemStack`.
- End Frame accepts Eye of Ender and Ender Pearl for the summoning ritual.
- Fixed mixed opaque/transparent `material_instances` on the Obsidilith End Frame.
- Kept the five-second Obsidilith summoning ritual and made filled frames able to resume it.

Bosses of Mass Destruction was created by Barribob. Upstream-derived assets and implementation material remain under LGPL-3.0-only; see the included license and notice files.
