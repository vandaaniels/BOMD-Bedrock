# Asset and project notice

This project contains two licensing layers:

- Original Bedrock JavaScript, JSON scaffolding, documentation, and test-arena
  work created for this prototype are licensed under the MIT License in
  `LICENSE`.
- Adapted Night Lich, Nether Gauntlet, and Void Blossom models, textures,
  animations, sounds, particle art, icon material, shared artifact assets, and
  the converted Lich Tower and Gauntlet Arena structures from
  *Bosses of Mass Destruction* remain licensed under LGPL-3.0-only. A copy is
  included in
  `LICENSES/LGPL-3.0-only.txt`.

The full upstream source, exact commit, imported-file inventory, and
transformation record are in `THIRD_PARTY_NOTICES.md`. The source archive
distributed beside the `.mcaddon` is the corresponding editable source for
this Bedrock adaptation.

The Java gameplay code was not copied into the add-on. The combat system was
independently reimplemented with Bedrock JSON and the stable Script API.

This is an independent, unofficial project. It is not approved by or
associated with Mojang, Microsoft, or the upstream mod author.
